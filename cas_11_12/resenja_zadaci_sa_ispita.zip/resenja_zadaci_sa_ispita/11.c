#include <stdio.h>
#include "liste.h"

int main(){
  Cvor *lista=NULL;
  ucitaj_listu1(&lista,stdin);

  Cvor *pomocni=lista;
  //pomocni sluzi da se krecemo kroz listu, jer lista mora na kraju da
  //pokazuje na pocetak
  while(pomocni!=NULL){
    int x=pomocni->vrednost;
    //pomocni1 sluzi da idemo od sledeceg elementa i proverimo da li smo
    //naisli ponovo na x
    Cvor *pomocni1=pomocni->sledeci;
    while(pomocni1!=NULL){
      if(pomocni1->vrednost==x){
	//ako naidjemo na x, prvo pomocni pomeramo sa pocetka
	//da pokazuje na prvi element koji nije x
	while(pomocni!=NULL && pomocni->vrednost==x)
	  pomocni=pomocni->sledeci;
	//brisemo x ali iz liste lista, jer ona uvek pokazuje na pocetak
	//bez obzira gde je stigao pomocni
	obrisi_cvor(&lista,x);
	break;
      }

      pomocni1=pomocni1->sledeci;
    }
    //ako pomocni nije stigao do kraja i ako je vrednost ostala ista
    //nakon unutrasnje petlje znaci da nismo imali brisanje tog elementa
    //pa se pomeramo za jedno mesto unapred
  
    if(pomocni!=NULL && pomocni->vrednost==x)
      pomocni=pomocni->sledeci;
  }
  
  ispisi_listu(lista);
  oslobodi_listu(lista);
  return 0;
}
