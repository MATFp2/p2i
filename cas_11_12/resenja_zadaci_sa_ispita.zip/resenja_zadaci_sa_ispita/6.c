#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

void f4(Cvor *lista){
  if(lista==NULL)
    return ;
  
  if(lista->sledeci){
    Cvor *tmp=lista->sledeci->sledeci;
    free(lista->sledeci);
    lista->sledeci=tmp;
    
    f4(lista->sledeci);
  }
}


int main(){
  Cvor *lista=NULL;

  ucitaj_listu1(&lista,stdin);

  f4(lista);
  ispisi_listu(lista);

  oslobodi_listu(lista);
  return 0;
}
