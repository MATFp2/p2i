#include <stdio.h>
#include "liste.h"

int f7(Cvor *lista){
  //hocemo da se zaustavimo kada sledeci postane NULL, tada znamo da smo dosli
  //do poslednjeg cvora
  while(lista->sledeci){
    if(lista->vrednost%2==0)
      lista->sledeci->vrednost++;
    else
      lista->sledeci->vrednost--;
    lista=lista->sledeci;
  }

  return lista->vrednost;
}

int main(){
  Cvor *lista=NULL;
  //NAPOMENA ako u zadatku nije naglaseno da se unosi do unosa 0
  //onda moramo ucitavati do EOF-a, zato obavezno pogledati
  // i tu verziju funkcije ucitaj_listu
  //u ovom zadatku imamo test primer koji sadrzi 0 u listi tako da bi
  //trebalo da koristimo tu verziju funkcije
  ucitaj_listu1(&lista,stdin);

  printf("%d\n",f7(lista));

  oslobodi_listu(lista);
  return 0;
}
