#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

//funkcija koja proverava da li se cvor x nalazi u listi lista
int uListi(int x,Cvor *lista){  
  while(lista){
    if(lista->vrednost==x)
      return 1;
    lista=lista->sledeci;
  }
  return 0;
}

int main(){  
  Cvor *lista1=NULL;
  Cvor *lista2=NULL;
  int suma=0;
  //NAPOMENA ako u zadatku nije naglaseno da se unosi do unosa 0
  //onda moramo ucitavati do EOF-a, zato obavezno pogledati funkciju
  // i tu verziju funkcije ucitaj_listu

  ucitaj_listu1(&lista1,stdin);
  ucitaj_listu1(&lista2,stdin);

  Cvor *tmp=lista1;
  while(tmp){
    if(!uListi(tmp->vrednost,lista2))
      suma+=tmp->vrednost;
    tmp=tmp->sledeci;
  }

  printf("%d\n",suma);

  oslobodi_listu(lista1);
  oslobodi_listu(lista2);
  
  return 0;
}
