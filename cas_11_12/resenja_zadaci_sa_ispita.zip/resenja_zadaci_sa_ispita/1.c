#include <stdio.h>
#include "liste.h"
#include <stdlib.h>

//funkcija koja brise 1 cvor sa pocetka liste
void obrisi_sa_pocetka(Cvor **lista){
  Cvor *tmp=*lista;
  *lista=(*lista)->sledeci;
  free(tmp);
}


int main(){
  FILE *fajl=fopen("izraz.txt","r");

  if(fajl==NULL)
    greska();

  Cvor *lista=NULL;
  int c;
  int ind=1;

  while((c=fgetc(fajl))!=EOF){
    //ako smo dosli do otvorene zagrade dodajemo je na pocetak
    if(c=='{' || c=='(' || c=='[')
      dodaj_na_pocetak(&lista,c);

    //ako smo dosli do zatvorene zagrade a lista je prazna, znaci da
    //je lose upareno
    if((c=='}' || c==']' || c==')') && lista==NULL){
      ind=0;
      break;
    }

    //ako je dosla neka zatvorena zagrada, a na pocetku steka je otvorena
    //zagrada istog tipa, onda skidamo sa pocetka steka, a ako je drugog tipa
    //postavljamo indikator na 0 i izlazimo iz petlje
    
    if(c=='}')
      if(lista->vrednost!='{'){
	ind=0;
	break;
      }
      else
	obrisi_sa_pocetka(&lista);
    
    if(c==']')
      if(lista->vrednost!='['){
	ind=0;
	break;
      }
      else
	obrisi_sa_pocetka(&lista);
    
    if(c==')')
      if(lista->vrednost!='('){
	ind=0;
	break;
      }
      else
	obrisi_sa_pocetka(&lista);
  }
  if(ind && lista==NULL)
    printf("Zagrade su dobro uparene\n");
  else
    printf("Zagrade nisu dobro uparene\n");
  return 0;
  
  oslobodi_listu(lista);
  fclose(fajl);
}
