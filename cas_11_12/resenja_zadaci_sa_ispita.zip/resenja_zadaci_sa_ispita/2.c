#include <stdio.h>
#include "liste.h"
#include <stdlib.h>

//NAPOMENA: u zadatku koristimo ucitavanje liste do unosa nule,
// koriscenjem funkcije ucitaj_listu
//ako se u zadatku ne trazi do unosa 0, onda ucitavamo do EOF-a
//obavezno pogledati i to kako se radi
int main(){
  int x,y,z;
  Cvor *lista=NULL;
  
  lista=ucitaj_listu(lista,stdin);

  printf("Unesite x, y i z:");
  scanf("%d %d %d",&x,&y,&z);
  
  Cvor *tekuci=lista;
  while(tekuci->sledeci!=NULL){
    if(tekuci->vrednost==x && tekuci->sledeci->vrednost==y){
      Cvor *novi=napravi_cvor(z);
      Cvor *tmp=tekuci->sledeci;
      tekuci->sledeci=novi;
      novi->sledeci=tmp;
      tekuci=novi->sledeci;
      continue;
    }
    tekuci=tekuci->sledeci;
  }
  ispisi_listu(lista);
  oslobodi_listu(lista);
  return 0;
}
