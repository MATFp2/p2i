#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

void umetni(Cvor *lista){
  if(lista==NULL || lista->sledeci==NULL)
    return ;
  
  int razlika=lista->vrednost-lista->sledeci->vrednost;
  Cvor *novi=napravi_cvor(razlika);
  Cvor *sledeci=lista->sledeci;

  lista->sledeci=novi;
  novi->sledeci=sledeci;

  umetni(novi->sledeci);
  
  return ;
}

int main(){  
  Cvor *lista=NULL;
  
  ucitaj_listu1(&lista,stdin);
  
  ispisi_listu(lista);
  umetni(lista);
  ispisi_listu(lista);
  
  oslobodi_listu(lista);
  
  return 0;
}
