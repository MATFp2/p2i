#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

Cvor *f2(Cvor *lista){
  Cvor *tmp=NULL;
  while(lista){
    dodaj_na_pocetak(&tmp,lista->vrednost);
    lista=lista->sledeci;
  }
  return tmp;
}


int main(){
  Cvor *lista=NULL;
  ucitaj_listu1(&lista,stdin);
  
  Cvor *obrnuta=f2(lista);
  ispisi_listu(obrnuta);

  oslobodi_listu(obrnuta);
  oslobodi_listu(lista);

  return 0;
}
