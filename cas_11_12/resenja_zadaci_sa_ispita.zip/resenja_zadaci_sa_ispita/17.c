#include <stdio.h>
#include "liste.h"
#include <stdlib.h>

//funkcija je identicna funkciji koja brise cvor sa zadatom
//vrednoscu x, ali se menja kriterijum brisanja
//tamo smo brisali kad god naidjemo na broj x, a
//ovde kad god naidjemo na broj deljiv sa x,
//sto znaci menjamo samo uslov u else if grani
//slicno je i za 16. zadatak
void obrisi_cvorove(Cvor** lista, int broj){
  if(*lista == NULL)
    return;
  else if(((*lista)->vrednost % broj)==0){
    Cvor* tmp = *lista;
    *lista = (*lista)->sledeci;
    free(tmp);
    obrisi_cvorove(lista, broj);
  }
  else
    obrisi_cvorove(&(*lista)->sledeci, broj);
}


int main(){
  int broj;
  Cvor *lista=NULL;
  ucitaj_listu1(&lista,stdin);

  scanf("%d",&broj);
  obrisi_cvorove(&lista,broj);

  ispisi_listu(lista);
}
