#include <stdio.h>
#include "liste.h"

Cvor *izbaci(Cvor *lista1,Cvor *lista2){
  if(lista2==NULL)
    return lista1;

  while(lista2){
    obrisi_cvor(&lista1,lista2->vrednost);
    lista2=lista2->sledeci;
  }
  
  return lista1;
}


int main(){
  Cvor *lista1=NULL;
  Cvor *lista2=NULL;

    //NAPOMENA ako u zadatku nije naglaseno da se unosi do unosa 0
  //onda moramo ucitavati do EOF-a, zato obavezno pogledati
  //i tu verziju funkcije ucitaj_listu

  ucitaj_listu1(&lista1,stdin);
  ucitaj_listu1(&lista2,stdin);

  Cvor *rez=izbaci(lista1,lista2);
 
  /*nakon ovoga lista1 i dalje pokazuje na pocetnu listu, medjutim
    neki elementi pocetne liste su oslobodjeni,
    tj. izbrisani u funkciji izbaci
    td koristimo rez nadalje.
    npr. pozvati program i uneti 1 2 3 4 5 6 0
                                 1 2 0
  i u mainu ispisati listu rez i ispod listu lista1, p
    rva dva elementa liste1 ce biti nesto sto ne bismo ocekivali. 
    To je zato sto smo funkciji izbaci prosledili samo pokazivac na listu,
    a ne njegovu adresu
  */

  ispisi_listu(rez);
  // ispisi_listu(lista1);


  oslobodi_listu(rez);
  oslobodi_listu(lista2);
  return 0;
}
