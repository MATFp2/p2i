#include <stdio.h>
#include <stdlib.h>

int main(){
	unsigned int x;
	unsigned int n;
	unsigned int niz[32];
	
	scanf("%u", &x);
	scanf("%u", &n);
	int i;
	for(i = 0; i < n; i++){
		scanf("%u", &niz[i]);
	}
	unsigned rez = 0;
	unsigned int mask = 1;
	for(i = 0; i < 32; i++){
		unsigned prvi = x & mask;
		unsigned drugi = 0;
		if(i < n)
			drugi = niz[i] & mask;
		
		//printf("%u %u\n", prvi, drugi);
		
		if(prvi == drugi){
			rez = rez | mask;
		}
		mask = mask << 1;
	}
	printf("%u", rez);
}