#include <stdio.h>
#include <string.h>

#define MAX_KARAKTERA 50

int main()
{
    FILE* ulaz = fopen("dat.txt","r");
    if(ulaz == NULL)
    {
        printf("-1\n");
        return -1;
    }
    
    int n;
    char prva_rec[MAX_KARAKTERA];
    char tekuca_rec[MAX_KARAKTERA];
    
    fscanf(ulaz,"%s",prva_rec);
    
    fscanf(ulaz,"%d",&n);
    if(n < 0)
    {
        printf("-1\n");
        return -1;
    }
    
    int i, j, k;
    char* str;
    int sufiks;
    for(i = 0; i < n; i++)
    {
        sufiks = 1;
        fscanf(ulaz,"%s",tekuca_rec);
        
        if(strstr(tekuca_rec, prva_rec) != NULL)
        {
            k = 0;
            for(j = strlen(tekuca_rec) - strlen(prva_rec); tekuca_rec[j] && prva_rec[k]; j++, k++)
                if(tekuca_rec[j] != prva_rec[k])
                {
                    sufiks = 0;
                    break;
                }
            if(sufiks)
                printf("%s ", tekuca_rec);
                
        }
    }
    
    fclose(ulaz);
    return 0;
}
