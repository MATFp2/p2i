#include <stdio.h>

#define MAX_DUZINA 1000

void f3(int *a, int na, int suma_prethodnih);

int main()
{
    int suma_prethodnih = 0;
    int i;
    int na;
    
    int a[MAX_DUZINA];
    
    scanf("%d",&na);
    if(na < 0 || na > MAX_DUZINA)
    {
        printf("-1\n");
        return -1;
    }
    
    for(i = 0; i < na; i++)
    {
        scanf("%d",&a[i]);
        suma_prethodnih += a[i];
    }
    
    f3(a, na, suma_prethodnih);
    
    for(i = 0; i < na; i++)
        printf("%d ",a[i]);
 
    return 0;
}

void f3(int *a, int na, int suma_prethodnih)
{
    if(na == 1)
        a[0] = 0;
    else
    {
        int za_brisanje = 0;
        na--;
        suma_prethodnih -= a[na];
        if(a[na] > suma_prethodnih)
            za_brisanje = 1;
        
        f3(a, na, suma_prethodnih);
        
        if(za_brisanje)
            a[na] = 0;
    }
}