#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    if(argc == 1)
    {
        printf("-1\n");
        return -1;
    }
    
    int n, i;
 
    int a = atoi(argv[1]);
    int b = atoi(argv[1]);
    double c = 0;
    
    int broj;
    
    for(i = 1; i < argc; i++)
    {
        broj = atoi(argv[i]);
        if(broj < a)
            a = broj;
        if(broj > b)
            b = broj;
        c += broj;
    }
    
    c = c / (argc-1);
    
    double izraz = (a + b + c)/3.0;
    
    for(i = 1; i < argc; i++)
        if(atoi(argv[i]) > izraz)
            printf("%s ",argv[i]);
    
    return 0;
}