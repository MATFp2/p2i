#include <stdio.h>

#define MAX_DUZINA 1000

void f3(int *a, int na);

int main()
{
    int na;
    int niz[MAX_DUZINA];
 
    scanf("%d",&na);
    
    if(na < 0 || na > MAX_DUZINA)
    {
        printf("-1\n"); 
        return -1;
    }
    
    int i;
    for(i = 0; i < na; i++)
        scanf("%d",&niz[i]);
    
    int *a;
    a = niz;
    
    f3(a, na);
    
    for(i = 0; i < na; i++)
        printf("%d ", a[i]);
    
    return 0;
}

void f3(int *a, int na)
{
    if(na == 1)
    {
        return;
    }
    else
    {
        if(a[0] % 2 == 0 && a[1] % 2 == 0)
            a[0]--;
        
        a++;
        f3(a, na-1);
    }
}