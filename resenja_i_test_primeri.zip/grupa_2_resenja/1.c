#include <stdio.h>
#include <stdlib.h>

int suma_cifara(int n);

int main(int argc, char** argv)
{
    int k, l, i;
    int suma = 0;
    
    if(argc != 3)
    {
        printf("-1\n");
        return -1;
    }
    
    k = atoi(argv[1]);
    l = atoi(argv[2]);

    if(k < 0 || k > 10000 || l < 0 || l > 10000)
	{
		printf("-1\n");
		return -1;
	}
    
    for(i = k; i <= l; i++)
        suma += suma_cifara(i);
    
    printf("%d\n",suma);
    
    return 0;
}

int suma_cifara(int n)
{
    int suma = 0;
    
    while(n != 0)
    {
        suma += n%10;
        n /= 10;
    }
    
    return suma;
}
