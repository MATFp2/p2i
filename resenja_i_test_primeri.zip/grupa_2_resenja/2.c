#include <stdio.h>

#define MAX_KARAKTERA 51

int main()
{
    char rec[MAX_KARAKTERA];
    
    FILE* ulaz1 = fopen("u1.txt","r");
    FILE* ulaz2 = fopen("u2.txt","r");
    FILE* izlaz = fopen("i.txt","w");
 
    if(ulaz1 == NULL || ulaz2 == NULL || izlaz == NULL)
    {
        printf("-1\n");
        return -1;
    }
    
    int n1, n2;
    
    fscanf(ulaz1, "%d", &n1);
    fscanf(ulaz2, "%d", &n2);
    
    if(n1 < 0 || n2 < 0)
    {
        printf("-1\n");
        return -1;
    }
    
    while(n1 > 0 || n2 > 0)
    {
        if(n1 > 0)
        {
            fscanf(ulaz1, "%s", rec);
            fprintf(izlaz, "%s ", rec);
            n1--;
        }
        
        if(n2 > 0)
        {
            fscanf(ulaz2, "%s", rec);
            fprintf(izlaz, "%s ", rec);
            n2--;
        }
    }
    
    fclose(ulaz1);
    fclose(ulaz2);
    fclose(izlaz);
    return 0;
}