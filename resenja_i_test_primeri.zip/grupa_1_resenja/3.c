#include <stdio.h>

int f3(int x);

int main()
{
    int n;
    
    scanf("%d",&n);
    
    if(n < 0)
    {
        printf("-1\n");
        return -1;
    }
    
    printf("%d\n",f3(n));
 
    return 0;
}

int f3(int x)
{
    if(x < 10)
        return x;
    else
    {
        int cifra = x % 10;
        int prethodna = (x/10) % 10;
        
        if(cifra % 2 == 0 || prethodna != 2)
            return f3(x/10) * 10 + cifra;
        else
            return f3(x/10);
    }
}