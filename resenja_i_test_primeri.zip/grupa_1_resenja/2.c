#include <stdio.h>
#include <ctype.h>

#define MAX_KARAKTERA 51

int broj(char rec[]);

int main()
{
    FILE* ulaz    = fopen("r.txt","r");
    FILE* brojevi = fopen("b.txt","w");
    FILE* ostalo  = fopen("o.txt","w");
 
    if(ulaz == NULL || brojevi == NULL || ostalo == NULL)
    {
        printf("-1\n");
        return -1;
    }
    
    int i, n;
    
    fscanf(ulaz, "%d", &n);
    if(n < 0)
    {
        printf("-1\n");
        return -1;
    }
    
    char rec[MAX_KARAKTERA];
    
    for(i = 0; i < n; i++)
    {
        fscanf(ulaz, "%s", rec);
        
        if(broj(rec))
            fprintf(brojevi, "%s ", rec);
        else
            fprintf(ostalo, "%s ", rec);
    }
    
    
    fclose(ulaz);
    fclose(brojevi);
    fclose(ostalo);
    return 0;
}

int broj(char rec[])
{
    int i;
    for(i = 0; rec[i]; i++)
        if(!isdigit(rec[i]))
            return 0;
    return 1;
}