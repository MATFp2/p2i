#include <stdio.h>
#include <stdlib.h>

int prost(int n);

int main(int argc, char** argv)
{
    int n;
    
    if(argc != 3)
    {
        printf("-1\n");
        return -1;
    }
    
    int k = atoi(argv[1]);
    int l = atoi(argv[2]);
        
    if(k > l || k < 2 || l < 2 || k > 10000 || l > 10000)
    {
        printf("-1");
        return -1;
    }
    
    int i;
    for(i = k; i <= l; i++)
        if(prost(i))
            printf("%d ",i);
}

int prost(int n)
{
    int i;
    
    for(i = 2; i < n; i++)
        if(n % i == 0)
            return 0;
    return 1;
}