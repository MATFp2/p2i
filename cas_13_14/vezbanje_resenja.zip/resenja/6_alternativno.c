// Alternativno resenje 6. zadatka - kod sa vezbi kod Stefana


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

typedef enum {
	BROJ,
	OPERATOR
} TipCvora;

// typedef struct _cvor {
// 	char operator; // '+'
// 	int broj;      // 123
// 	// nesto da ih razlikujemo;
// 	// int da_li_je_broj;
// 	TipCvora tip;  
// 	struct _cvor *levo;
// 	struct _cvor *desno;
// } Cvor;

// typedef enum {
// 	PLUS,
// 	MINUS
// 	...
// } OP;

typedef struct _cvor {
	TipCvora tip;
	union {
		struct {
			char op;
			struct _cvor *levo;
			struct _cvor *desno;
		} operator;

		int broj;
	} vrednost;
} Cvor;

void greska(const char *s)
{
	fprintf(stderr, "%s\n", s);
	exit(EXIT_FAILURE);
}

#define MAX 15

Cvor *ucitaj(FILE *f)
{
	char s[MAX];
	if(fscanf(f, "%s", s) == EOF) {
		return NULL;
	}
	Cvor *novi = malloc(sizeof *novi);
	if(novi == NULL) {
		greska("alokacija cvora");
	}

	if(s[0] == '+' || s[0] == '-' || s[0] == '*' || s[0] == '/') {
		if(s[1] != '\0') {
			greska("pogresan format - nije operator, ali lici");
		}
		novi->tip = OPERATOR;
		novi->vrednost.operator.op = s[0];
		novi->vrednost.operator.levo = ucitaj(f);
		if(novi->vrednost.operator.levo == NULL) {
			greska("pogresan format - nema levog operanda");
		}
		novi->vrednost.operator.desno = ucitaj(f);
		if(novi->vrednost.operator.desno == NULL) {
			greska("pogresan format - nema desnog operanda");
		}
	} else {
		for(int i = 0; s[i]; i++) {
			if(!isdigit(s[i])) {
				greska("pogresan format - nije ni broj ni operator");
			}
		}
		novi->tip = BROJ;
		novi->vrednost.broj = atoi(s);
	}
	return novi;
}

void ispisi(Cvor *koren)
{
	if(koren != NULL) {
		if(koren->tip == OPERATOR) {
			printf("(");
			ispisi(koren->vrednost.operator.levo);
			printf(")%c(", koren->vrednost.operator.op);
			ispisi(koren->vrednost.operator.desno);
			printf(")");
		} else {
			printf("%d", koren->vrednost.broj);
		}
	}
}

void oslobodi(Cvor *koren)
{
	if(koren != NULL) {
		if(koren->tip == OPERATOR) {
			oslobodi(koren->vrednost.operator.levo);
			oslobodi(koren->vrednost.operator.desno);
		}
		free(koren);
	}
}

float izracunaj_vrednost(Cvor *koren)
{
	if(koren == NULL) {
		return 0;
	}
	if(koren->tip == OPERATOR) {
		float vrednost_levog_operanda = izracunaj_vrednost(koren->vrednost.operator.levo);
		float vrednost_desnog_operanda = izracunaj_vrednost(koren->vrednost.operator.desno);
		if(koren->vrednost.operator.op == '+') {
			return vrednost_levog_operanda + vrednost_desnog_operanda;
		} else if(koren->vrednost.operator.op == '*') {
			return vrednost_levog_operanda * vrednost_desnog_operanda;
		} else if(koren->vrednost.operator.op == '-') {
			return vrednost_levog_operanda - vrednost_desnog_operanda;
		} else {
			if(vrednost_desnog_operanda == 0) {
				greska("deljenje nulom");
			}
			return vrednost_levog_operanda / vrednost_desnog_operanda;
		}
	} else {
		return koren->vrednost.broj;
	}
}

int main()
{
	FILE *f = fopen("karakteri.txt", "r");
	if(f == NULL) {
		greska("otvaranje fajla");
	}
	Cvor *koren = ucitaj(f);
	fclose(f);

	ispisi(koren);
	printf("\n%f\n", izracunaj_vrednost(koren));

	oslobodi(koren);


	return 0;
}