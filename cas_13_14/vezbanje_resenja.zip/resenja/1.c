 #include<stdio.h>
 #include "stabla.h"
 
 Cvor* pretrazi_stablo(Cvor* koren, int broj)
{
	if(koren == NULL)
		return NULL;
	
	if(koren->vrednost == broj)
		return koren;
	else if(broj < koren->vrednost)
		return pretrazi_stablo(koren->levo, broj);
	else
		return pretrazi_stablo(koren->desno, broj);
}

Cvor* pronadji_najmanji(Cvor* koren)
{
	if(koren == NULL)
		return NULL;
	if(koren->levo == NULL)
		return koren;
	return pronadji_najmanji(koren->levo);
}

Cvor* pronadji_najveci(Cvor* koren)
{
	if(koren == NULL)
		return NULL;
	if(koren->desno == NULL)
		return koren;
	return pronadji_najveci(koren->desno);
}

 
 int main()
 {
        //Obavezna inicijalizacija stabla
	Cvor* s = NULL;
	
	ucitaj_stablo(&s, stdin);
	Cvor * min = pronadji_najmanji(s);
	
	ispisi_stablo(s, stdout);
	printf("\n");
	
	if(min != NULL)
		printf("Najmanji clan: %d\n", min->vrednost);
	
	ispisi_stablo(s, stdout);
	printf("\n");
	
	oslobodi_stablo(s);
 return 0;
 }
