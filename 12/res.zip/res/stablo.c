#include "stablo.h"

void greska()
{
  printf("-1\n");
  exit(EXIT_FAILURE);
}

_cvor* novi(int br)
{
	_cvor* n = malloc(sizeof(_cvor));
	
	if (n == NULL)
	{
		printf("greska\n");
		exit(EXIT_FAILURE);
	}
	
	n->vred = br;
	n->levo = NULL;
	n->desno = NULL;
	
	return n;
}

_cvor* ubaci_u_stablo(_cvor* glava, int br)
{
	//levo <= korena < desno
	if (glava == NULL)
	{
		return novi(br);
	}
	
	if (glava->vred < br) //ubacujemo u desno
		glava->desno = ubaci_u_stablo(glava->desno, br);
	else
		glava->levo = ubaci_u_stablo(glava->levo, br);
	
	return glava;
}

void ispis(_cvor* glava, FILE* f)
{
	//levo-koren-desno
	if (glava != NULL)
	{
		ispis(glava->levo, f);
		fprintf(f, "%d ", glava->vred);
		ispis(glava->desno, f);
	}
}

void ispis1(_cvor* glava, FILE* f)
{
	//levo-desno-koren
	if (glava != NULL)
	{
		ispis1(glava->levo, f);
		ispis1(glava->desno, f);
		fprintf(f, "%d ", glava->vred);
	}
}


void ispis2(_cvor* glava, FILE* f)
{
	//koren-levo-deno
	if (glava != NULL)
	{
		fprintf(f, "%d ", glava->vred);
		ispis2(glava->levo, f);
		ispis2(glava->desno, f);
	}
}

void oslobodi(_cvor* glava)
{
	if (glava != NULL)
	{
		oslobodi(glava->levo);
		oslobodi(glava->desno);
		free(glava);
	}
}

_cvor* unos(FILE* f)
{
	_cvor* glava = NULL;
	int br;
	
	while(fscanf(f, "%d", &br) != EOF)
	{
		glava = ubaci_u_stablo(glava, br);
	}
	
	return glava;
}







