#include "stablo.h"

//rekurziju za levo
//rekurzija za desno
//odraditi nesto sa korenom i onim sto je rekurzija vratila

//ispisati listove stabla
void ispis_listova(_cvor* glava)
{
	//bazni slucajevi
	if (glava == NULL)
		return;
		
	if (glava->levo == NULL && glava->desno == NULL)
		printf("%d ", glava->vred);
	else
	{
		ispis_listova(glava->levo);
		ispis_listova(glava->desno);
	}
	//nista ne radimo sa korenom jer on nije list
}


//racuna sumu svih listova
int suma_listova(_cvor* glava)
{
	int sl, sd;
	
	if (glava == NULL)
		return 0;
	if (glava->levo == NULL && glava->desno == NULL)
		return glava->vred;
		
	sl = suma_listova(glava->levo);
	sd = suma_listova(glava->desno);
	
	return sl + sd;
}

//izracunati sumu svih elemenata
int suma(_cvor* glava)
{
	if (glava == NULL)
		return 0;
		
	int sl = suma(glava->levo);
	int sd = suma(glava->desno);
	
	return sl+sd+ glava->vred;
}


//maksimalna vrednost u stablo
//da znamo da je stablo sortirano
int maks1(_cvor* glava)
{
	if (glava == NULL)
		exit(0);

	if (glava->desno == NULL)
		return glava->vred;

	return maks1(glava->desno);
}

//maksimalna vrednost
//da ne znamo da je stablo sortirano
int maks2(_cvor* glava)
{
	int m1, m2;

	if (glava == NULL)
		exit(0);
	if (glava->levo == NULL && glava->desno == NULL)
		return glava->vred;
		
	if (glava->levo == NULL)
	{
		m1 = maks2(glava->desno);
		return glava->vred > m1 ? glava->vred : m1;
	}
	
	if (glava->desno == NULL)
	{
		m2 = maks2(glava->levo);
		return glava->vred > m2 ? glava->vred : m2;
	}

	m1 = maks2(glava->levo);
	m2 = maks2(glava->desno);
	
	m1 = m1 > m2 ? m1 : m2;
	
	return glava->vred > m1 ? glava->vred : m1;
}

//odrediti dubinu/visinu stabla
int dubina(_cvor* glava)
{
	if (glava == NULL)
		return 0;
		
	int dl = dubina(glava->levo);
	int dd = dubina(glava->desno);
	
	if (dl > dd)
		return dl+1;
	else
		return dd+1;
}

int ravnomerno_izbalansirano(_cvor* glava)
{
	if (glava == NULL)
		return 1;
		
	//proveravamo izbalansiranost levog i desnog
	int rl = ravnomerno_izbalansirano(glava->levo);
	int rd = ravnomerno_izbalansirano(glava->desno);
	
	if (rl == 0 || rd == 0)
		return 0;
		
	//sad proveravamo za celo drvo
	int dl = dubina(glava->levo);
	int dd = dubina(glava->desno);
	
	if (abs(dl - dd) <= 1)
		return 1;
	else
		return 0;
}

int iste_parnost(_cvor* drvo)
{
	if (drvo == NULL)
		return 0;
	if (drvo->levo == NULL)
		return iste_parnost(drvo->desno);
	if (drvo->desno == NULL)
		return iste_parnost(drvo->levo);
		
	int il = iste_parnost(drvo->levo);
	int id = iste_parnost(drvo->desno);
	
	if ((drvo->vred%2==0 && drvo->levo->vred%2==0 && drvo->desno->vred%2 == 0) || (drvo->vred%2==1 && drvo->levo->vred%2==1 && drvo->desno->vred%2 == 1))
		return il + id + 1;
	else
		return il + id;
}

_cvor* ogledalo(_cvor* glava)
{
	if (glava == NULL)
		return NULL;

	_cvor* l = ogledalo(glava->levo);
	_cvor* d = ogledalo(glava->desno);
	
	glava->levo = d;
	glava->desno = l;
	
	return glava;
}

//brojimo one koji su jednaki razlici sinova
int f5(_cvor* stablo)
{
	if (stablo == NULL)
		return 0;
	
	
	int l = f5(stablo->levo);
	int d = f5(stablo->desno);
	
	if (stablo->levo == NULL)
		return d;
	if (stablo->desno == NULL)
		return l;
		
	if (stablo->vred == stablo->desno->vred - stablo->levo->vred)
		return l + d + 1;
	else
		return l + d;
}

int f8(_cvor* stablo, int nivo)
{
  if (stablo == NULL)
	return 0;
  
  if (nivo == 1)
	return 1;
  else
	return f8(stablo->levo, nivo-1) + f8(stablo->desno, nivo-1);
}

int vece(int vred, _cvor* stablo)
{
  if (stablo == NULL)
	return 1;
  
  if (vred > stablo->vred)
  {
	return vece(vred, stablo->levo) && vece(vred, stablo->desno);
  }
  else 
	return 0;
}

int br_cvorova(_cvor* stablo)
{
  if (stablo == NULL)
	return 0;
  
  if (stablo->levo != NULL && stablo->desno != NULL)
  {
	if (vece(stablo->vred, stablo->levo) && vece(stablo->vred, stablo->desno))
	  return 1 + br_cvorova(stablo->levo) + br_cvorova(stablo->desno);
	else
	  return br_cvorova(stablo->levo) + br_cvorova(stablo->desno);
  }
  else if (stablo->levo != NULL)
  {
	if (vece(stablo->vred, stablo->levo))
	  return 1 + br_cvorova(stablo->levo);
	else
	  return br_cvorova(stablo->levo);
  }
  else if (stablo->desno != NULL)
  {
	if (vece(stablo->vred, stablo->desno))
	  return 1 + br_cvorova(stablo->desno);
	else
	  return br_cvorova(stablo->desno);
  }
  else
	return 0;
}

int identicna(_cvor* stablo1, _cvor* stablo2)
{
  if (stablo1 == NULL && stablo2 == NULL)
	return 1;
  
  if (stablo1 == NULL)
	return 0;
  
  if (stablo2 == NULL)
	return 0;
  
  if (stablo1->vred != stablo2->vred)
	return 0;
  
  return identicna(stablo1->levo, stablo2->levo) && identicna(stablo1->desno, stablo2->desno);
}

int par_nepar(int a, int b, int c)
{
  if (a%2 == 0 && b%2==0 &&c%2==0)
	return 1;
  else if (a%2 == 1 && b%2==1 &&c%2==1)
	return 1;
  else
	return 0;
}

int prebroj(_cvor* stablo)
{
  if (stablo == NULL)
	return 0;
  
  if (stablo->levo == NULL || stablo->desno == NULL)
	return 0;
  
  if (par_nepar(stablo->vred, stablo->levo->vred, stablo->desno->vred))
	return 1 + prebroj(stablo->levo) + prebroj(stablo->desno);
  else
	return prebroj(stablo->levo) + prebroj(stablo->desno);
}

int suma_cif(int a)
{
  int suma = 0;
  
  if (a < 0)
	a = -a;
  
  while(a)
  {
	suma += a%10;
	a /=10;
  }
  
  return suma;
}

int zbir_cifara(_cvor* stablo)
{
  if (stablo == NULL)
	return 0;
  
  return suma_cif(stablo->vred) + zbir_cifara(stablo->levo) + zbir_cifara(stablo->desno);
}

int f5_15(_cvor* stablo)
{
  if (stablo == NULL)
	return 0;
  
  if (zbir_cifara(stablo->levo) > zbir_cifara(stablo->desno))
	return 1 + f5_15(stablo->levo) + f5_15(stablo->desno);
  else
	return f5_15(stablo->levo) + f5_15(stablo->desno);
}


int f5_16(_cvor* stablo, int k)
{
  if (stablo == NULL)
	return 0;
  
  if (k == 1)
  {
	if (stablo->vred % 2 == 0)
	  return stablo->vred;
	else
	  return -stablo->vred;
  }
  
  return f5_16(stablo->levo, k-1) + f5_16(stablo->desno, k-1);
}

void f5_17(_cvor* stablo)
{
  if (stablo == NULL)
	return;
  
  if (dubina(stablo->levo) > dubina(stablo->desno))
  {
	_cvor* pom = stablo->levo;
	stablo->levo = stablo->desno;
	stablo->desno = pom;
  }
  
  f5_17(stablo->levo);
  f5_17(stablo->desno);
}

int main(int argc, char** argv)
{
	_cvor* glava = NULL;
	
	if (argc != 3)
	  greska();
	
	//kao datoteke moze se dati i standarni ulaz i izlaz i taj slucaj se
	//prilikom otvaranja i zatvaranja datoteka posebno obradjuje
	FILE* ulaz;
	FILE* izlaz;
	
	if (strcmp(argv[1], "stdin") == 0)
	  ulaz = stdin;
	else
	  ulaz = fopen(argv[1], "r");
	
	
	if (strcmp(argv[2], "stdout") == 0)
	  izlaz = stdout;
	else
	  izlaz = fopen(argv[2], "w");
	
	if (ulaz == NULL || izlaz == NULL)
	{
		printf("greska\n");
		exit(0);
	}
	
	glava = unos(ulaz);
	
	
	//ispis(glava, izlaz);
	//ispis_listova(glava);
	//printf("%d\n", suma(glava));
	//printf("%d\n", suma_listova(glava));
	//printf("%d\n", maks2(glava));
	//printf("%d\n", dubina(glava));
	
	/*
	int n;
	printf("unesi nivo ");
	scanf("%d", &n);
	printf("%d\n", f8(glava, n)); */
	
	//printf("%d\n", f5(glava));
	
	//printf("%d\n", br_cvorova(glava));
	
	/*
	glava = ogledalo(glava);
	ispis(glava, izlaz);*/
	
	/*
	 * 
	FILE *ulaz2;
	
	if (strcmp(argv[2], "stdin") == 0)
	  ulaz2 = stdin;
	else
	  ulaz2 = fopen(argv[2], "r");
	
	_cvor* glava2 = NULL;
	
	glava2 = unos(ulaz2);
	
	if (identicna(glava, glava2))
	  printf("jednaka su\n");
	else
	  printf("nisu jednaka\n");
	
	if (ulaz2 != stdin)
	  fclose(ulaz2);
	
	oslobodi(glava2);
	*/
	
	//printf("%d\n", ravnomerno_izbalansirano(glava));
	
	//printf("%d\n", prebroj(glava));
	
	//printf("%d\n", f5_15(glava));
	
	/*
	int n;
	printf("unesi nivo ");
	scanf("%d", &n);
	printf("%d\n", f5_16(glava, n));*/
	
	f5_17(glava);
	ispis(glava, izlaz);

	oslobodi(glava);
	
	if (ulaz != stdin)
	  fclose(ulaz);
	
	if (izlaz != stdout)
	  fclose(izlaz);
	
	return 0;
}