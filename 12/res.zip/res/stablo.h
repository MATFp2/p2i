#ifndef STABLO_H
#define STABLO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Cvor
{
	int vred;
	struct Cvor* levo;
	struct Cvor* desno;
}_cvor;

void greska();

_cvor* novi(int br);

_cvor* ubaci_u_stablo(_cvor* glava, int br);

//infix
void ispis(_cvor* glava, FILE* f);


//postfix
void ispis1(_cvor* glava, FILE* f);


//prefix
void ispis2(_cvor* glava, FILE* f);


void oslobodi(_cvor* glava);

//za unos stabla
//citamo brojeve dok ne dodjemo do kraja dat
_cvor* unos(FILE* ulaz);

#endif //STABLO_H


