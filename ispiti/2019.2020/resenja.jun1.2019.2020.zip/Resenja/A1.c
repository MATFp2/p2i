#include <stdio.h>
#include <stdlib.h>

#define DUZINA_LINIJE 201
#define DUZINA_IMENA 16

void greska(){
  fprintf(stderr,"-1\n");
  exit(1);
}

int main(){
  FILE *ulaz=fopen("fajlovi.txt","r");
  if(ulaz==NULL)
    greska();

  char linija[DUZINA_LINIJE];
  char ime_fajla[DUZINA_IMENA];

  while(fgets(linija,DUZINA_LINIJE,ulaz)!=NULL){
    int i;
    for(i=0;linija[i]!=':';i++)
      ime_fajla[i]=linija[i];
    ime_fajla[i]='\0';
    

    FILE *fajl=fopen(ime_fajla,"a");
    if(fajl==NULL)
      greska();

    fprintf(fajl,"%s",linija+i+1);
    fclose(fajl);
  }

  fclose(ulaz);
  return 0;
}
