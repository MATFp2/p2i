#include <stdio.h>
#include <stdlib.h>
#define MAX_IME 16
#define MAX_STUDENTI 128

typedef struct student{
  int broj;
  int godina;
  char ime[MAX_IME];
  char prezime[MAX_IME];
}Student;


void insertion_sort(Student *niz,int n){
  int i, j;
  for(i=1; i<n; i++){
      Student trenutni = niz[i];
      for(j=i; j>0 && (trenutni.broj < niz[j-1].broj || (trenutni.broj==niz[j-1].broj && trenutni.godina>niz[j-1].godina)); j--)
	niz[j] = niz[j-1];
      niz[j] = trenutni;
    }
}

int main(){
  int i=0;
  Student studenti[MAX_STUDENTI];

  while(scanf("%d/%d %s %s",&studenti[i].broj,&studenti[i].godina,studenti[i].ime,studenti[i].prezime)!=EOF){
    i++;
  }

  int n=i;

  insertion_sort(studenti,n);
  
  for(i=0;i<n;i++)
    printf("%d/%d %s %s\n",studenti[i].broj,studenti[i].godina,studenti[i].ime,studenti[i].prezime);

  return 0;
}
