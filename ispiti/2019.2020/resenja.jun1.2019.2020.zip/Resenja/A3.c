#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 16

typedef struct cvor{
  char ime[MAX];
  char prezime[MAX];
  double prosek;
  struct cvor *sledeci;
}Cvor;

void greska(){
  fprintf(stderr,"-1\n");
  exit(1);

}

Cvor *napraviCvor(char *ime,char *prezime,double prosek){
  Cvor *novi=(Cvor *)malloc(sizeof(Cvor));
  if(novi==NULL)
    greska();

  strcpy(novi->ime,ime);
  strcpy(novi->prezime,prezime);
  novi->prosek=prosek;
  novi->sledeci=NULL;
  return novi;
}


void dodajNaKraj(Cvor **glava,char *ime,char *prezime,double prosek){
  Cvor *novi=napraviCvor(ime,prezime,prosek);
  
  if((*glava)==NULL)
    *glava=novi;
  else{
    Cvor *pom=*glava;
    while(pom->sledeci!=NULL)
      pom=pom->sledeci;

    pom->sledeci=novi;
  }

}


double suma(Cvor *glava, double k){
  double s=0;
  while(glava){
    if(glava->prosek>k)
      s+=glava->prosek;

    glava=glava->sledeci;
  }
  
  return s;
}

int main(){
  Cvor *glava=NULL;
  char ime[MAX];
  char prezime[MAX];
  double prosek;
  double k;
  char ime_dat[MAX];
  scanf("%lf %s",&k,ime_dat);
  
  
  FILE *ulaz=fopen(ime_dat,"r");
  if(ulaz==NULL)
    greska();
  
  while(fscanf(ulaz,"%s %s %lf",ime,prezime,&prosek)!=EOF){
    if(prosek<6 || prosek >10)
      greska();
    dodajNaKraj(&glava,ime,prezime,prosek);
  }

  printf("%.2f\n",suma(glava,k));

  return 0;
}
