#include <stdio.h>
#include "stabla.h"



int zbir(Cvor *koren){
  if(koren==NULL)
    return 0;

  if((koren->levo==NULL && koren->desno!=NULL) || (koren->levo!=NULL && koren->desno==NULL))
    return koren->vrednost+zbir(koren->levo)+zbir(koren->desno);

  return zbir(koren->levo)+zbir(koren->desno);
}


void ispisi(Cvor *koren,int k){
  if(koren){
    ispisi(koren->levo,k);
    if(koren->vrednost>k)
      printf("%d ",koren->vrednost);
    ispisi(koren->desno,k);
  }
  

}

int main(){

  
  Cvor *koren=NULL;

  napravi_stablo_iz_fajla_v2(&koren,stdin);

  int x=zbir(koren);
  printf("%d ",x);
  ispisi(koren,x);
  printf("\n");

  oslobodi(koren);
  return 0;
}
