#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct _cvor
{
	double x;
	double y;
	double rastojanje;
	struct _cvor *levo, *desno;
}Cvor;

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

double rastojanje(double x, double y)
{
	return sqrt(x * x + y * y);
}

Cvor *napraviCvor(double x, double y)
{
	Cvor *novi = malloc(sizeof(Cvor));

	if (novi == NULL)
		greska();

	novi->desno = NULL;
	novi->levo = NULL;

	novi->x = x;
	novi->y = y;
	novi->rastojanje = rastojanje(x, y);

	return novi;
}


Cvor *dodajUStablo(Cvor *koren, double x, double y)
{
	if (koren == NULL)
		return napraviCvor(x, y);
	else {
		if (koren->rastojanje > rastojanje(x, y))
			koren->levo = dodajUStablo(koren->levo, x, y);
		else
			koren->desno = dodajUStablo(koren->desno, x, y);

		return koren;
	}
}

void ispisi(Cvor *koren, double k)
{
	if (koren == NULL)
		return;

	ispisi(koren->levo, k);
	ispisi(koren->desno, k);

	if (koren->rastojanje > k)
		printf("%.2lf %.2lf\n", koren->x, koren->y);
}

void osolobodi(Cvor* koren)
{
	if (koren != NULL)
	{
		osolobodi(koren->levo);
		osolobodi(koren->desno);
		free(koren);
	}
}

int main(int argc, char** argv)
{
	if (argc != 2)
		greska();

	FILE *ulaz = fopen(argv[1], "r");
	if (ulaz == NULL)
		greska();

	Cvor *stablo = NULL;

	double broj_x, broj_y;
	while(fscanf(ulaz, "%lf%lf", &broj_x, &broj_y) != EOF) {
		stablo = dodajUStablo(stablo, broj_x, broj_y);
	}

	double k;
	scanf("%lf", &k);

	if (k < 0)
		greska();

	ispisi(stablo, k);

	osolobodi(stablo);

	fclose(ulaz);
	return 0;
}