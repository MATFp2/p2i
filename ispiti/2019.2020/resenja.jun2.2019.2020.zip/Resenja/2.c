#include <stdio.h>
#include <stdlib.h>

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int pozicija_jedinice(int *niz, int levo, int desno)
{
	if (levo > desno)
		return -1;

	int sredina = (levo + desno)/2;

	if (niz[sredina] == 1) {
		if (sredina == 0)
			return 0;

		if (niz[sredina - 1] == 0)
			return sredina;

		if (niz[sredina - 1] == 1)
			return pozicija_jedinice(niz, levo, sredina - 1);
	} else 
		return pozicija_jedinice(niz, sredina + 1, desno);
}

int main()
{
	int n;
	int *niz = NULL;

	scanf("%d", &n);

	if (n <= 0)
		greska();

	niz = malloc(n * sizeof(int));
	if (niz == NULL)
		greska();

	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &niz[i]);
	}


	printf("%d\n", pozicija_jedinice(niz, 0, n));


	free(niz);

	return 0;
}