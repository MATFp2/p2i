#include <stdio.h>
#include <stdlib.h>

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int main(int argc, char** argv)
{
	int s, n;
	double **matrica = NULL;

	if (argc != 3)
		greska();

	s = atoi(argv[1]);
	n = atoi(argv[2]);

	if (n <= 0 || s < 0)
		greska();

	matrica = malloc(n * sizeof(double*));
	if (matrica == NULL)
		greska();
	for(int i = 0; i < n ; i++) {
		matrica[i] = malloc(n * sizeof(double));
		if (matrica[i] == NULL)
			greska();
	}

	srand(s);

	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			matrica[i][j] = (double)rand()/RAND_MAX;
		}
	}


	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			printf("%.6lf ", matrica[i][j]);
		}
		putchar('\n');
	}

	//oslobadjanje
	for (int i = 0; i < n; i++)
		free(matrica[i]);
	free(matrica);

	return 0;
}