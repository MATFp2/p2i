#include <stdio.h>
#include <stdlib.h>

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

double slucajan()
{
	return ((double)rand()/RAND_MAX)*(100) - 50;
}

int main()
{
	srand(8);
	for (int i = 0; i < 200; ++i)
	{
		printf("%lf %lf\n", slucajan(), slucajan());
	}

	
}