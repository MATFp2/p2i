#include "liste.h"

void ubaci(Cvor* lista, int x)
{
	if (lista == NULL)
		return;

	if (lista->sledeci == NULL)
		return;

	if (lista->vrednost >= 0 && lista->sledeci->vrednost >= 0) {
		Cvor* pomocni = lista->sledeci;
		Cvor* novi = napravi_cvor(x);
		lista->sledeci = novi;
		novi->sledeci = pomocni;

		ubaci(novi->sledeci, x);
	} else
		ubaci(lista->sledeci, x);
}

int main()
{
	Cvor* lista = NULL;
	int x;

	scanf("%d", &x);
	lista = ucitaj_listu_v2(stdin);

	ubaci(lista, x);

	ispisi_listu(lista, stdout);

	oslobodi_listu(lista);

	return 0;
}