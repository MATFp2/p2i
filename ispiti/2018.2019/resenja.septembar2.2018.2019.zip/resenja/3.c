#include "liste.h"

#define KORAK 10

typedef struct 
{	
	int broj;
	int broj_pojavljivanja;
}bb;

int postoji(bb *niz, int n, int broj)
{
	for(int i=0; i<n; i++)
		if (niz[i].broj == broj)
			return i;

	return -1;
}

int main()
{
	Cvor *lista = NULL;
	ucitaj_listu(&lista, stdin);
	bb *niz = NULL;
	int i = 0;
	int alocirano = 0;

	while (lista)
	{
		int indeks = postoji(niz, i, lista->vrednost);
		if (indeks != -1)
		{
			niz[indeks].broj_pojavljivanja++;
		} else {
			if (i == alocirano) {
				alocirano += KORAK;
				niz = realloc(niz, alocirano*sizeof(bb));
				if (niz == NULL)
					greska();
			}
			niz[i].broj = lista->vrednost;
			niz[i].broj_pojavljivanja = 1;
			i++;
		}
		lista = lista->sledeci;
	}
	
	for(int j=0; j<i; j++)
		printf("%d: %d\n", niz[j].broj, niz[j].broj_pojavljivanja);
	
	oslobodi_listu(lista);
	free(niz);
	return 0;
}