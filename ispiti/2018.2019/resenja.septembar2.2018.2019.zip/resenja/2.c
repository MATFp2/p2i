#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void greska(){
	fprintf(stderr, "-1");
	exit(EXIT_FAILURE);
}

int kvadratni_stepen(int x){
	int br = 1;

	while(br <= sqrt(x)){
		if(br*br == x || br*br == -x)
			return 1;

		br++;
	}

	return 0;
}

void kvadrati(unsigned a, unsigned b){
	if(a>b){
		printf("\n");
		return;
	}

	if(kvadratni_stepen(a))
		printf("%d ", a);
	
	kvadrati(a+1, b);
}

int main(int argc, char** argv){
	unsigned a, b;

	if(argc!=3)
		greska();

	a = atoi(argv[1]);
	b = atoi(argv[2]);

	if(b<a)
		greska();

	kvadrati(a, b);

	return 0;
}
