#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_LEN 51

void greska(){
	fprintf(stderr, "-1");
	exit(EXIT_FAILURE);
}

int main(){
	FILE *in1, *in2;
	char dir1[MAX_LEN], dir2[MAX_LEN];
	int indikator1, indikator2;

	in1=fopen("dir1.txt", "r");
	in2=fopen("dir2.txt", "r");
	if(in1==NULL || in2==NULL)
		greska();

	indikator1 = fscanf(in1, "%s", dir1);
	indikator2 = fscanf(in2, "%s", dir2);

	while(indikator1!=EOF && indikator2!=EOF){
		if(strcmp(dir1, dir2) < 0){
			printf("%s\n", dir1);
			indikator1 = fscanf(in1, "%s", dir1);
		}
		else if(strcmp(dir1, dir2) > 0){
			printf("%s\n", dir2);
			indikator2 = fscanf(in2, "%s", dir2);
		}
		else{  
			printf("%s\n", dir1);
			indikator1 = fscanf(in1, "%s", dir1);
			indikator2 = fscanf(in2, "%s", dir2);
		}
	}

	while(indikator1!=EOF){
		printf("%s\n", dir1);
		indikator1 = fscanf(in1, "%s", dir1);
	}

	while(indikator2!=EOF){
		printf("%s\n", dir2);
		indikator2 = fscanf(in2, "%s", dir2);
	}

	fclose(in1);
	fclose(in2);

	return 0;
}
