#include<stdio.h>
#include"stabla.h"

int degenerisano_u_listu(Cvor* glava){
	int indikator;           //0 znaci levo, 1 znaci desno

	if (glava==NULL)
	  return 1;
	if(glava->levo!=NULL && glava->desno!=NULL)
		return 0;
	else if(glava->levo!=NULL)
		indikator = 0;
	else if(glava->desno!=NULL)
		indikator = 1;
	
	while(indikator==0 && glava!=NULL){
		if(glava->desno!=NULL)
			return 0;	
		glava = glava->levo;
	}
	
	while(indikator==1 && glava!=NULL){
		if(glava->levo!=NULL)
			return 0;	
		glava = glava->desno;
	}

	return 1;
}

int main(){
	Cvor *glava1=NULL, *glava2=NULL, *glava3=NULL;
	FILE *dat1,*dat2,*dat3;
	dat1=fopen("dat1.txt","r");
	dat2=fopen("dat2.txt","r");
	dat3=fopen("dat3.txt","r");
	
	glava1 = napravi_stablo_iz_fajla(dat1);
        glava2 = napravi_stablo_iz_fajla(dat2);	
	glava3 = napravi_stablo_iz_fajla(dat3);
	
	printf("%d ", degenerisano_u_listu(glava1));
        printf("%d ", degenerisano_u_listu(glava2));
	printf("%d\n", degenerisano_u_listu(glava3));
	
	oslobodi(glava1);
	oslobodi(glava2);
	oslobodi(glava3);

	return 0;
}
