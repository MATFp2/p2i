#include<stdio.h>

unsigned izmeni(unsigned x){
  unsigned maska = 15;
  
  while(maska!=0){
    x = x | maska;
    
    maska <<= 8;
  }
  
  return x;
}

int main(){
  unsigned x;
  
  scanf("%x", &x);
  
  x = izmeni(x);
  
  printf("0x%x\n", x);
  
  return 0;
}