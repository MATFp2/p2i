#include<stdio.h>
#include<stdlib.h>

#define MAX_LEN 21
#define MAX 500

typedef struct{
	char ime[MAX_LEN];
	char prezime[MAX_LEN];
	char indeks[MAX_LEN];
	int br_poena;
} Student;

void greska(){
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

void insertion_sort(Student* niz, int n){
	int i, j;
	Student insert_elem;

	for(i=1; i<n; i++){
		insert_elem=niz[i];
		for(j=i-1; j>=0; j--){
			if(niz[j].br_poena < insert_elem.br_poena)
				niz[j+1]=niz[j];
			else
				break;
		}
		if((j+1)!=i)
			niz[j+1]=insert_elem;
	}
}

int main(int argc, char** argv){
	FILE* in;
	Student niz[MAX];
	int i, n;

	if(argc!=2)
		greska();

	in=fopen(argv[1], "r");
	if(in==NULL)
		greska();

	i=0; 
	while(fscanf(in, "%s %s %s %d", niz[i].ime, niz[i].prezime, niz[i].indeks, &niz[i].br_poena) != EOF)
		i++;
	n=i;

	insertion_sort(niz, n);

	for(i=0; i<n; i++)
		printf("%s %s %s %d\n", niz[i].ime, niz[i].prezime, niz[i].indeks, niz[i].br_poena);

	fclose(in);		

	return 0;
}

