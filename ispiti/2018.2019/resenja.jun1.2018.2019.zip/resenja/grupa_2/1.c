#include<stdio.h>
#include<stdlib.h>

#define MAX_LEN 51
#define KORAK 10

typedef struct{
	char naziv[MAX_LEN];
	int br_sati;
	int br_minuta;
	int br_sekundi;
	int br_milisekundi;
} Fajl;

void greska(){
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int pretvori_u_milisekunde(Fajl f){
	int milisekundi=0;
	
	milisekundi+=f.br_milisekundi;
	milisekundi+=1000*f.br_sekundi;
	milisekundi+=1000*60*f.br_minuta;
	milisekundi+=1000*60*60*f.br_sati;

	return milisekundi;
}

int poredi(const void* prvi, const void* drugi){
	Fajl* prvi_f=(Fajl*)prvi;
	Fajl* drugi_f=(Fajl*)drugi;

	return pretvori_u_milisekunde(*prvi_f) - pretvori_u_milisekunde(*drugi_f);
}

int main(int argc, char** argv){
	FILE* in;
	int i, n, alocirano = KORAK;

	Fajl* niz = malloc(alocirano * sizeof(Fajl));
	if(niz == NULL)
		greska();

	if(argc!=2)
		greska();

	in=fopen(argv[1], "r");
	if(in==NULL)
		greska();

	n = 0;
	while(fscanf(in, "%s%d%*c%d%*c%d%*c%d", niz[n].naziv, &niz[n].br_sati, &niz[n].br_minuta, &niz[n].br_sekundi, &niz[n].br_milisekundi) != EOF){
		n++;
		if(n == alocirano) {
			alocirano += KORAK;
			niz = realloc(niz, alocirano * sizeof(Fajl));
			if(niz == NULL)
				greska();
		}
	}

	qsort(niz, n, sizeof(Fajl), &poredi);

	for(i=0; i<n; i++)
		printf("%s %d:%d:%d.%d\n", niz[i].naziv, niz[i].br_sati, niz[i].br_minuta, niz[i].br_sekundi, 
                                           niz[i].br_milisekundi);

	fclose(in);
	free(niz);

	return 0;
}
