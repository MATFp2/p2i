#include<stdio.h>
#include<stdlib.h>
#include"liste.h"

void ispisi_neke(Cvor* glava){
	//kada je prazna lista
	if(glava==NULL)
		return;

	//specijalan slucaj kada lista ima samo jedan cvor
	if(glava->sledeci==NULL)
		return;

	while(glava->sledeci!=NULL){
		if(glava->sledeci->vrednost >= glava->vrednost)
			printf("%d ", glava->sledeci->vrednost);

		glava=glava->sledeci;
	}
}


int main(){
	Cvor* glava=NULL;
	int vrednost;

	while(scanf("%d", &vrednost) != EOF)
		dodaj_na_kraj(&glava, vrednost);

	ispisi_neke(glava);
	
	oslobodi_listu(glava);

	return 0;
}
