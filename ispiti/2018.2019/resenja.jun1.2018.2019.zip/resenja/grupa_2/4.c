#include "stabla.h"

void izmeni(Cvor* koren)
{
	if (koren == NULL)
		return;

	Cvor *novi = napravi_cvor(koren->vrednost);

	novi->levo = koren->levo;
	koren->levo = novi;

	izmeni(koren->desno);
	izmeni(koren->levo->levo);
}

int main()
{
	Cvor *koren = NULL;

	koren = napravi_stablo_iz_fajla(stdin);

	izmeni(koren);

	ispisi_u_fajl(koren, stdout);
	printf("\n");

	oslobodi(koren);

	return 0;
}
