#include<stdio.h>
#include<stdlib.h>

#define MAX 1000
#define MAX_LEN 51

typedef struct{
	char naziv[MAX_LEN];
	int br_sati;
	int br_minuta;
	int br_sekundi;
	int br_milisekundi;
} Fajl;

void greska(){
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int pretvori_u_milisekunde(Fajl f){
	int milisekundi=0;
	
	milisekundi+=f.br_milisekundi;
	milisekundi+=1000*f.br_sekundi;
	milisekundi+=1000*60*f.br_minuta;
	milisekundi+=1000*60*60*f.br_sati;

	return milisekundi;
}

int poredi(const void* prvi, const void* drugi){
	Fajl* prvi_f=(Fajl*)prvi;
	Fajl* drugi_f=(Fajl*)drugi;

	return pretvori_u_milisekunde(*prvi_f) - pretvori_u_milisekunde(*drugi_f);
}

int main(int argc, char** argv){
	FILE* in;
	Fajl niz[MAX];
	int i, n;
	char c;

	if(argc!=2)
		greska();

	in=fopen(argv[1], "r");
	if(in==NULL)
		greska();

	i=0;
	while(fscanf(in, "%s%d%c%d%c%d%c%d", niz[i].naziv, &niz[i].br_sati, &c, &niz[i].br_minuta, &c, &niz[i].br_sekundi, &c,
                                             &niz[i].br_milisekundi) != EOF){
		i++;
	}
	n=i;

	qsort(niz, n, sizeof(Fajl), &poredi);

	for(i=0; i<n; i++)
		printf("%s %d:%d:%d.%d\n", niz[i].naziv, niz[i].br_sati, niz[i].br_minuta, niz[i].br_sekundi, 
                                           niz[i].br_milisekundi);

	fclose(in);

	return 0;
}
