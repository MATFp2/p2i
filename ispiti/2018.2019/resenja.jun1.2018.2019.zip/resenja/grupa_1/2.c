#include<stdio.h>

unsigned zameni(unsigned x){
	unsigned maska_levo=1<<(sizeof(unsigned)*8-1);
	unsigned maska_desno=1<<(sizeof(unsigned)*4-1);
	unsigned rez=0;

	while(maska_desno!=0){
		if((x&maska_levo)!=0)
			rez=rez|maska_desno;
		if((x&maska_desno)!=0)
			rez=rez|maska_levo;

		maska_levo>>=1;
		maska_desno>>=1;
	}	

	return rez;
}

int main(){
	unsigned x;

	scanf("%x", &x);
	printf("0x%x\n", zameni(x));

	return 0;
}
