#include <stdio.h>
#include <stdlib.h>
#include "liste.h"

void umetni(Cvor *lista)
{
	if (lista == NULL || lista->sledeci == NULL)
		return;

	if (lista->vrednost % 2 == 0 &&
		lista->sledeci->vrednost % 2 == 0)
	{
		Cvor* novi = napravi_cvor(0);
		novi->sledeci = lista->sledeci;
		lista->sledeci = novi;
		umetni(lista->sledeci->sledeci);
	}
	else
		umetni(lista->sledeci);
}

int main()
{
	Cvor *lista = NULL;

	ucitaj_listu(&lista, stdin);

	umetni(lista);

	ispisi_listu(lista);

	oslobodi_listu(lista);

	return 0;
}
