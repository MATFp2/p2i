#include<stdio.h>

unsigned invertuj(unsigned x){
	unsigned maska_desno=1;
	unsigned maska_levo=1<<(sizeof(unsigned)*4);

	while(maska_desno < maska_levo){
		x=x^maska_desno;
		maska_desno<<=2;
	}

	maska_levo<<=1;

	while(maska_levo!=0){
		x=x^maska_levo;
		maska_levo<<=2;
	}

	return x;
}

int main(){
	unsigned x;
	
	scanf("%x", &x);
	printf("0x%x\n", invertuj_parne(x));

	return 0;
}
