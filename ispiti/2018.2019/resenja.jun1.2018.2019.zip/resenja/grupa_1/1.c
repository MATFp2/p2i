#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_BROJ_KARTICE 17
#define KORAK 10

typedef struct {
	char broj_kartice[MAX_BROJ_KARTICE];
	double suma;
}kartica_t;

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int poredi_kartica(const void* a, const void* b)
{
	kartica_t x = *(kartica_t*)a;
	kartica_t y = *(kartica_t*)b;

	return strcmp(x.broj_kartice, y.broj_kartice);
}

/* Napraviti test primer da se uhvati slucaj kad neko uradi return x - y. */
int poredi_suma(const void *a, const void *b)
{
	kartica_t x = *(kartica_t*)a;
	kartica_t y = *(kartica_t*)b;

	if (x.suma > y.suma)
		return -1;
	else if (x.suma < y.suma)
		return 1;
	else
		return 0;	
}

int main(int argc, char** argv)
{
	if (argc != 4)
		greska();

	char *ime_fajla = NULL;
	ime_fajla = malloc((strlen(argv[1]) + strlen(argv[2]) + 6)*sizeof(char));
	if (ime_fajla == NULL)
		greska();

	sprintf(ime_fajla, "%s_%s.txt", argv[1], argv[2]);

	//printf("%s\n", ime_fajla);

	FILE *f = fopen(ime_fajla, "r");
	if (f == NULL)
		greska();

	kartica_t *niz = NULL;
	int dim = 0;
	int alocirano = KORAK;
	char broj_kartice[MAX_BROJ_KARTICE];
	double suma;
	int i;

	niz = malloc(alocirano*sizeof(kartica_t));
	if (niz == NULL)
		greska();

	while(fscanf(f, "%s%lf", broj_kartice, &suma) != EOF) {
		int postoji = 0;
		for(i=0; i<dim; i++)
			if (strcmp(niz[i].broj_kartice, broj_kartice) == 0) {
				niz[i].suma += suma;
				postoji = 1;
				break;
			}

		if (!postoji) {
			strcpy(niz[dim].broj_kartice, broj_kartice);
			niz[dim].suma = suma;
			dim++;
		}

		if (dim == alocirano) {
			alocirano += KORAK;
			niz = realloc(niz, alocirano*sizeof(kartica_t));
			if (niz == NULL)
				greska();
		}
	}

	if (strcmp(argv[3], "-kartica") == 0)
		qsort(niz, dim, sizeof(kartica_t), &poredi_kartica);
	else if (strcmp(argv[3], "-suma") == 0)
		qsort(niz, dim, sizeof(kartica_t), &poredi_suma);

	for(i=0; i<dim; i++)
		printf("%s %lf\n", niz[i].broj_kartice, niz[i].suma);

	free(niz);
	fclose(f);
	free(ime_fajla);
	return 0;
}
