#include "stabla.h"
// u prva dva test primra ne stavljati ni jednu izlaznu kobinaciju kao sa papira
// i kombinacije oblika 1 1 1 i 0 0 0 

int simetricno_ss(Cvor* koren1, Cvor* koren2)
{
	if (koren1 == NULL && koren2 == NULL)
		return 1;

	if (koren1 == NULL || koren2 == NULL)
		return 0;

	return simetricno_ss(koren1->levo, koren2->desno) &&
	       simetricno_ss(koren1->desno, koren2->levo);
}

int simetricno(Cvor* koren)
{
	if (koren == NULL)
		return 1;

	return simetricno_ss(koren->levo, koren->desno);
}

int main()
{
	Cvor* koren1 = NULL;
	Cvor* koren2 = NULL;
	Cvor* koren3 = NULL;
	FILE *ulaz1=fopen("dat1.txt","r");
	FILE *ulaz2=fopen("dat2.txt","r");
	FILE *ulaz3=fopen("dat3.txt","r");
	
	koren1 = napravi_stablo_iz_fajla(ulaz1);
	koren2 = napravi_stablo_iz_fajla(ulaz2);
	koren3 = napravi_stablo_iz_fajla(ulaz3);
	

	printf("%d\n", simetricno(koren1));
	printf("%d\n", simetricno(koren2));
	printf("%d\n", simetricno(koren3));

	oslobodi(koren1);
	oslobodi(koren2);
	oslobodi(koren3);

	return 0;
}
