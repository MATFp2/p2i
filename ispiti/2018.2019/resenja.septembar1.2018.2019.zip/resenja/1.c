#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_DIM 21
#define KORAK 10

typedef struct {
  char grad[MAX_DIM];
  double plata;
}grad_t;

void greska()
{
  fprintf(stderr, "-1\n");
  exit(EXIT_FAILURE);
}

int poredi(const void *a, const void *b)
{
  grad_t x = *(grad_t*)a;
  grad_t y = *(grad_t*)b;

  int cmp = strcmp(x.grad, y.grad);

  if (cmp != 0)
    return cmp;
  else {
    if (x.plata > y.plata)
      return -1;
    else if (x.plata < y.plata)
      return 1;
    else 
      return 0;
  }
}

int main(int argc, char** argv)
{
  if (argc != 2)
    greska();

  int k = atoi(argv[1]);

  if (k < 1)
    greska();

  FILE *f = fopen("plate.txt", "r");
  if (f == NULL) 
    greska();

  grad_t *niz = NULL;
  int i = 0;
  int alocirano = KORAK;

  niz = malloc(alocirano*sizeof(grad_t));
  if (niz == NULL)
    greska();

  while(fscanf(f, "%s%lf", niz[i].grad, &niz[i].plata) != EOF) {
    i++;
    if (i == alocirano) {
      alocirano += KORAK;
      niz = realloc(niz, alocirano*sizeof(grad_t));
      if (niz == NULL)
	greska();
    }
  }

  qsort(niz, i, sizeof(grad_t), &poredi);

  if (i != 0) {
    char trenutni_grad[MAX_DIM];
    int ispis = 0;

    strcpy(trenutni_grad, niz[0].grad);

    for(int j=0; j<i; j++) {
      if (ispis < k) {
	if (strcmp(trenutni_grad, niz[j].grad) == 0) {
	  printf("%s %.3lf\n", niz[j].grad, niz[j].plata);
	  ispis++;
	}
	else {
	  printf("%s %.3lf\n", niz[j].grad, niz[j].plata);
	  strcpy(trenutni_grad,niz[j].grad);
	  ispis = 1;
	}
      } else {
	if (strcmp(trenutni_grad, niz[j].grad) == 0)
	  continue;
	else {
	  printf("%s %.3lf\n", niz[j].grad, niz[j].plata);
	  strcpy(trenutni_grad,niz[j].grad);
	  ispis = 1;
	}
      }
    }
  }

  fclose(f);
  free(niz);
  return 0;
}
