#include "liste.h"

int main()
{
	Cvor *lista = NULL;
	ucitaj_listu(&lista, stdin);

	Cvor* p1 = lista;
	Cvor* p2 = lista;

    // ovo je napredno resenje
    // mogu da prebroje koliko elemenata ima pa na taj nacin da se pozicioniraju na sredinu
	while (p1 != NULL && p1->sledeci != NULL)
	{
		p1 = p1->sledeci->sledeci;
		p2 = p2->sledeci;
	}
	if (p1 != NULL)
		p2 = p2->sledeci;
	p1 = lista;

	//printf("%d\n", p1->vrednost);
	//printf("%d\n", p2->vrednost);
	//pretpostaviti da zadata lista uvek ima paran broj elementa
	while(p2)
	{
	  //printf("%d\n", p1->vrednost);
	  //	printf("%d\n", p2->vrednost);

		Cvor *pomocni_p1 = p1->sledeci;
		Cvor *pomocni_p2 = p2->sledeci;

		p1->sledeci = p2;

		if (pomocni_p2 != NULL) {
			p2->sledeci = pomocni_p1;
			p2 = pomocni_p2;
			p1 = pomocni_p1;
		} else 
			break;
	}
	
	ispisi_listu(lista, stdout);
	oslobodi_listu(lista);


	return 0;
}
