#include <stdio.h>

int main()
{
	int x;
	unsigned int mask = 1;
	int broj_krajnjih_nula = 0;
	int broj_vodecih_nula = 0;

	scanf("%d", &x);

	while(mask) {
		if (!(mask & x))
			broj_krajnjih_nula++;
		else
			break;
		mask <<= 1;
	}

	mask = 1 << (sizeof(int)*8 - 1);
	while (mask) {
		if (!(mask & x))
			broj_vodecih_nula++;
		else
			break;
		mask >>= 1;		
	}

	printf("%d %d\n", broj_vodecih_nula, broj_krajnjih_nula);

	return 0;
}