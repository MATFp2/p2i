#include<stdio.h>
#include<stdlib.h>

int  f(x)
{
	return 1 + f(x/10);
}

int main()
{

printf("%d\n", f(12345));
return 0;
}