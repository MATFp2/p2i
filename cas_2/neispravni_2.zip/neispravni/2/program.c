// Program sa standardnog ulaza ucitava niz karaktera do pojave znaka ! a zatim na standardni izlaz ispisuje ucitani niz.
// 3 greske

#include <stdio.h>
#include <stdlib.h>

void greska();

int main()
{
    char *niz;
    char *pom;
    char c;
    int i = 0;
    
    while((c = getchar()) != '!')
    {
        pom = realloc(niz, (i-1) * sizeof(char));
        if(pom == NULL)
            greska();
        
        niz[i] = c;
        i++;
    }
    
    int n = i;
    for(i = 0; i < n; i++)
        printf("%c", niz[i]);
    
    free(pom);
    free(niz);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}

