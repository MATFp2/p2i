// Program sa standardnog ulaza ucitava pozitivan ceo broj n, niz od n registarskih brojeva (kao deo strukture VOZILO) u zasebnim redovima (niske maksimalne duzine 13 karaktera) a zatim na standardni izlaz ispisuje ucitane registarske brojeve
// 4 greske

#include <stdio.h>
#include <stdlib.h>

#define MAX_TABLICE 14

void greska();
void ispisi_vozila(VOZILO* niz, int n);

typedef struct {
    char *registarski_broj;
} VOZILO;

int main()
{
    VOZILO *niz;
    int n; 
    char c;
    
    scanf("%d", &n);
    if(n <= 0)
        greska();
    
    int i, j;
    for(i = 0; i < n; i++)
    {
        niz[i]->registarski_broj = (char*)malloc(MAX_TABLICE * sizeof(char));
        if(niz[i].registarski_broj == NULL)
            greska();
        
        j = 0;
        while((c = getchar()) != '\n')
        {
            niz[i].registarski_broj[j] = c;
            j++;
        }
        niz[i].registarski_broj[j] = '\0';
    }
    
    ispisi_vozila(niz, n);
    
    free(niz);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}

void ispisi_vozila(VOZILO* niz, int n)
{
    int i;
    for(i = 0; i < n; i++)
        printf("%s", niz[i]);
}
