// Program ucitava pozitivan ceo broj n kao argument komandne linije, alocira niz od n elemenata koji su svi jednaki 1 i ispisuje ih na standardni izlaz
// Program testirati pozivom ./a.out 20
// 3 greske
 
#include <stdio.h>
#include <stdlib.h>
 
void greska();
 
int main()
{
    int n;
     
    if(argc != 2)
    {
        greska();
    }
     
    n = argv[1];
    
    if(n <= 0)
        greska();
     
    int* niz;
     
    niz = (int*)malloc(n);
    if(niz == NULL)
        greska();
     
    int i;
     
    for(i = 0; i < n; i++)
        niz[i] = 1;
     
    for(i = 0; i < n; i++)
        printf("%d ", niz[i]);
    
    free(niz);
}
 
void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}