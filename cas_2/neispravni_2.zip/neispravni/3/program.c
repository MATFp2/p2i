// Program ucitava pozitivan ceo broj n, alocira prostor za n niski duzine 100 karaktera (bez belina) a zatim ispisuje ucitane niske na standardni izlaz
// Program testirati za n > 5
// 3 greske

#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA_NISKE 101

int main()
{
    char** niske;
    
    int n;
    int i;
    
    scanf("%d", &n);
    if(n <= 0)
        greska();
    
    niske = (char**)malloc(n * sizeof(char));
    if(niske == NULL)
        greska();
    
    for(i = 0; i < n; i++)
    {
        niske[i] = (char*)malloc(MAX_DUZINA_NISKE * sizeof(char));
        if(niske[i] == NULL)
            greska();
    }
 
    for(i = 0; i < n; i++)
        scanf("%s", niske[i]);
    
    for(i = 0; i < n; i++)
        printf("%s\n", niske[i]);
    
    free(niske);
    for(i = 0; i < n; i++)
        free(niske[i]);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}
