// Program ucitava sa standardnog ulaza broj n, niz od n celih brojeva a zatim ispisuje niz na standardni izlaz koristeci funkciju void unos_ispis(int ** niz, int n);
// 4 greske

#include <stdio.h>
#include <stdlib.h>

void greska();

void unos_ispis(int **niz, int n);

int main()
{
    int* niz;
    int n;
    
    scanf("%d", &n);
    if(n <= 0)
        greska();
 
    unos_ispis(niz, n);
    
    free(niz);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}

void unos_ispis(int **niz, int n)
{
    niz = (int*)malloc(n * sizeof(int));
    if(*niz == NULL)
        greska();
    
    int i;
    for(i = 0; i < n; i++)
        scanf("%d", niz[i]);
    
    for(i = 0; i < n; i++)
        printf("%d", niz[i]);
}
