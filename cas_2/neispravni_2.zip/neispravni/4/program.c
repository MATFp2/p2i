// Program na standardni izlaz ispisuje DA ako su svi argumenti komandne linije celi pozitivni brojeve, inace ispisuje NE
// 3 greske

#include <stdio.h>

int main(int argc, char **argv)
{
    int i, j;
    
    if(argc < 2)
    {
        printf("NE");
        return 0;
    }
    
    for(i = 0; i < argc; i++)
    {
        for(j = 0; argv[i]; j++)
            if(!isdigit(argv[i][j]))
            {
                printf("OVDE: %c\n", argv[i][j]);
                printf("NE");
                return 0;
            }
    }
    
    printf("DA");
 
    return 0;
}