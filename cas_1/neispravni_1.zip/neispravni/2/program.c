// Program ispisuje prvu rec iz datoteke "ulaz.txt" na standardni izlaz. Duzina reci je najvise 10 karaktera
// 2 greske. Testirati sa datotekom ciji je sadraj "OK".

#include <stdio.h>
#include <stdlib.h>

#define MAX_SADRZAJ 1

void greska();

int main()
{
    FILE* ulaz = fopen("ulaz.txt","w");
    if(ulaz == NULL)
        greska();
    
    char sadrzaj[MAX_SADRZAJ];
    printf("%s", fgets(sadrzaj, MAX_SADRZAJ, ulaz));
 
    fclose("ulaz.txt");
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}
