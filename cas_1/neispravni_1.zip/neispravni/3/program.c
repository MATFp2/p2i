// Program ispisuje prvu rec iz datoteke "ulaz.txt", duzina reci je najvise 10 karaktera
// 2 greske + potrebna popravka "lepote koda"

#include <stdio.h>
#include <stdlib.h>
#define MAX_BAFER 11

void greska();

int main()
{
    FILE *ulaz = fopen("ulaz.txt","r");
    if(ulaz == NULL)
        greska();
        fclose(ulaz);
 
    char bafer[MAX_BAFER];
    fscanf(ulaz, "%s", bafer);
    fclose(ulaz);
    
    fprintf("stdout","%s",bafer);
    
    return 0;
}

void greska()
{
    fprintf(stderr,"-1");
    exit(EXIT_FAILURE);
}
