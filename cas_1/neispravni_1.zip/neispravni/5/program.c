// Program sa standardnog ulaza ucitava broj n i karakter c a zatim n puta
// upisuje karakter c u datoteku "izlaz.txt"
// 1 greska

#include <stdio.h>
#include <stdlib.h>

void greska();

int main()
{
    FILE *izlaz = fopen("izlaz.txt", "w");
    if(izlaz == NULL)
        greska();
    
    int n;
    char c;
    
    scanf("%d", &n);
    scanf("%c", &c);
    
    int i;
    for(i = 0; i < n; i++)
        fprintf(izlaz, "%c", c);
    
    fclose(izlaz);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}