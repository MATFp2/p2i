// Program ispisuje sadrzaj datoteke "ulaz.txt" na standardni izlaz karakter po karakter
// 4  greske

#include <stdio.h>
#include <stdlib.h>

void greska();

int main()
{
    FILE *ulaz = fopen("ulaz.txt","r");
    if(ulaz == NULL)
        greska();
    
    char c;
    while(c = fgetc(ulaz) != NULL);
    {
        putchar(c);
    }
    
    fclose(ulaz);
    return 0;
}

void greska()
{
    fprintf("stderr", "-1");
    exit(EXIT_FAILURE);
}