// Program sa standardnog ulaza ucitava broj n i naziv datoteke, nisku s, a zatim na standardni izlaz n puta ispisuje sadrzaj datoteke ciji je naziv naveden. Duzina naziva datoteke je najvise 10 karaktera.
// Testirati program sa ulaznom datotekom "ulaz.txt"
// 4 greske

#include <stdio.h>
#include <stdlib.h>

#define MAX_DATOTEKA 1

void greska();

int main()
{
    char s[MAX_DATOTEKA];
    int n;
    
    fscanf(stdin, "%n", &n);
    fscanf(stdin, "%s", s);
    
    int i;
    char c;
    
    FILE *ulaz;
    
    for(i = 0; i < n; i++)
    {   
        ulaz = fopen(s, "r");
        if(ulaz == NULL)
            greska();
        
        while((c = fgetc(ulaz)) != EOF)
            printf("%c", c); 
        
    }
    
    fclose(ulaz);
    return 0;
}

void greska()
{
    fprintf(stderr, "-1");
    exit(EXIT_FAILURE);
}