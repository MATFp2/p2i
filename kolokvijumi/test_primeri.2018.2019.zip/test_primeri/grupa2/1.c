#include <stdio.h>
#include <stdlib.h>

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int slucajan(int a, int b)
{
	return random()%(b - a) + a;
}

int main(int argc, char** argv)
{
	int n, k, i;
	int *niz = NULL;

	srandom(5);

	if (argc != 3)
		greska();

	n = atoi(argv[1]);
	k = atoi(argv[2]);

	if (n < 1 || k < 1)
		greska();


	niz = malloc(n*sizeof(int));
	if (niz == NULL)
		greska();

	for(i=0; i<n; i++)
		scanf("%d", &niz[i]);

	for(i=0; i<k; i++)
		printf("%d\n", niz[slucajan(0, n)]);

	free(niz);
	return 0;
}