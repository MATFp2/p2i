#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_LINIJA 201

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int broj_cifara(char *linija)
{
	int i = 0;
	int br_c = 0;

	while (linija[i]) {
		if (isdigit(linija[i]))
			br_c++;
		i++;
	}

	return br_c;
}

int main(int argc, char** argv)
{
	char linija[MAX_LINIJA];
	int redni_broj = 1;
	FILE *f;

	if (argc != 2)
		greska();

	f = fopen(argv[1], "r");
	if (f == NULL)
		greska();

	while(fgets(linija, MAX_LINIJA, f) != NULL) {
		printf("%d: %d\n", redni_broj, broj_cifara(linija));
		redni_broj++;
	}

	fclose(f);
	return 0;
}