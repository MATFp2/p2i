#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_LINIJA 201

void greska(){
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int main(int argc, char** argv){
	FILE* in;
	char linija[MAX_LINIJA];

	if(argc!=3)
		greska();

	in=fopen(argv[1], "r");
	if(in==NULL)
		greska();

	while(fgets(linija, MAX_LINIJA, in) != NULL){
		if(strstr(linija, argv[2]+1) != NULL)
			printf("%s", linija);
	}
	
	fclose(in);

	return 0;
}
