#include <stdio.h>
#include <stdlib.h>

void greska()
{
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int f3(int x)
{
	if (x < 10)
		return 0;

	int poslednja = x % 10;
	int pretposlednja = (x / 10) % 10;

	if (poslednja < pretposlednja)
		return 1 + f3(x/10);
	else
		return f3(x/10);
}

int main()
{
	int broj;

	scanf("%d", &broj);

	if (broj < 0){
		broj = -broj;
	}

	printf("%d\n", f3(broj));

	return 0;
}