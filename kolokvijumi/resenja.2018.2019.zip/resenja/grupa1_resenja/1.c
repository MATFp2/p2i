#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#define KORAK 10

void greska(){
	fprintf(stderr, "-1\n");
	exit(EXIT_FAILURE);
}

int main(int argc, char** argv)
{
	int* koef;
	int trenutna_duzina, i, x, n;
	int *novi = NULL;

	if (argc != 2)
		greska();

	int k = atoi(argv[1]);

	koef=(int*)malloc(KORAK*sizeof(int));
	if(koef==NULL)
		greska();

	trenutna_duzina=KORAK;

	i=0;
	while(scanf("%d", &x) != EOF){
		if(i==trenutna_duzina){
			koef=(int*)realloc(koef, (trenutna_duzina+KORAK)*sizeof(int));
			if(koef==NULL)
				greska();

			trenutna_duzina+=KORAK;
		}
		koef[i]=x;
		i++;
	}
	n=i;	//duzina vektora
	
	k = k%n;

	novi = malloc(n*sizeof(int));
	if (novi == NULL)
		greska();

	for(i=0; i<k; i++)
		novi[i] = koef[(n-k)+i];
	for(i=k; i<n; i++)
		novi[i] = koef[i - k];

	for(i=0; i<n; i++)
		printf("%d\n", novi[i]);

	free(koef);
	free(novi);
	return 0;
}
