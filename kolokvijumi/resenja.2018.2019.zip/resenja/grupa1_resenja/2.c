#include<stdio.h>
int zbir(int x){
	if(x/16==0)
		return x;
	else
		return x%16+zbir(x/16);
}

int main(){	
	unsigned x;

	printf("Unesite broj x: ");
	scanf("%x", &x);
	
	printf("Zbir heksadekadnih cifara je %d\n", zbir(x));

	return 0;
}
