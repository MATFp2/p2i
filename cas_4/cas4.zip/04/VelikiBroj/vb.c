#include "velikibroj.h"

void greska()
{
  fprintf(stderr, "-1\n");
  exit(EXIT_FAILURE);
}

/*Funkcija koja ucitava jedan veliki broj iz fajla.
U funkciji se alocira i memorija za strukturu i memorija za 
clan strukture (cifre), pa memoriju oslobadjamo u main-u kad zavrsimo rad sa strukturom.
*/
VelikiBroj* ucitaj(FILE *f){
  VelikiBroj *vb=NULL;
  int i = 0;
  int alocirano = 0;
  char karakter;

  //alokacija jedne strukture VelikiBroj
  vb=malloc(sizeof(VelikiBroj));
  if(vb==NULL)
    greska();
  
  vb->cifre = NULL;
  //ucitavamo cifre i realociramo memoriju sa korakom KORAK
  while(fscanf(f, "%c", &karakter) != EOF){
    if (alocirano == i){
      alocirano += KORAK;
      vb->cifre = realloc(vb->cifre, alocirano*sizeof(int));
      if (vb->cifre == NULL)
	greska();
    }
	
    //ako naidjemo na novi red zavrsavamo sa ucitavanjem
    
    if (karakter != '\n'){
      //ako je nesto razlicito od cifre, zavrsavamo rad
      if (!isdigit(karakter))
	greska();
      //ako je cifra, ubacujemo je u niz 'cifre'
      vb->cifre[i] = karakter - '0';
    }
    else
      break;
    
    i++;
  }
  //postavljamo broj cifara
  vb->broj_cifara = i;
  
  return vb;
}
/*Funkcija koja ispisuje veliki broj vb u fajl na koji pokazuje 
stream g
*/
void ispis(const VelikiBroj *vb, FILE *g){
  int i;
  
  for(i=0; i< vb->broj_cifara; i++)
    fprintf(g, "%d", vb->cifre[i]);
  
  fprintf(g, "\n");
}

//1 ako je prvi veci
//0 ako su isti
//-1 ako je prvi manji
int poredi(const VelikiBroj *vb1,const  VelikiBroj *vb2){
  int i;

  if (vb1->broj_cifara > vb2->broj_cifara)
    return 1;
  
  if (vb1->broj_cifara < vb2->broj_cifara)
    return -1;
  
  for(i=0; i< vb1->broj_cifara; i++) 
    if (vb1->cifre[i] > vb2->cifre[i])
      return 1;
    else if (vb1->cifre[i] < vb2->cifre[i])
      return -1;
  
  return 0;			
}

/*Funkcija sabira dva broja a i b, i vraca rezultat.
Rezultat je alociran unutar funkcije saberi, pa i njega moramo da oslobodimo u main-u.
*/
VelikiBroj* saberi(const VelikiBroj *a,const  VelikiBroj *b){
  VelikiBroj *c=NULL;

  //alociramo memoriju za rezultat
  c=malloc(sizeof(VelikiBroj));
  if(c==NULL)
    greska();

  c->cifre=NULL;

  //rezultat ima onoliko cifara koliko ima veci broj,
  //eventualno za jedan vise u slucaju prenosa
  if (a->broj_cifara > b->broj_cifara)
    c->broj_cifara = a->broj_cifara;
  else
    c->broj_cifara = b->broj_cifara;
  
  c->cifre = malloc((c->broj_cifara + 1)* sizeof(int));
  if (c->cifre == NULL)
    greska();
  
  int i = a->broj_cifara - 1; //poslednja od a
  int j = b->broj_cifara - 1; //poslednja od b
  int k = c->broj_cifara - 1;  //poslednja cifra od c
  int prenos = 0;
	
  //sabiramo cifru po cifru i pamtimo prenos dok god ima cifara u oba broja
  while (i >=0 && j>= 0){
    c->cifre[k] = (a->cifre[i] + b->cifre[j] + prenos) % 10;
    prenos     = (a->cifre[i] + b->cifre[j] + prenos) / 10;
    
    k--;
    i--;
    j--;
  }
	
  //slucaj da je prvi broj veci
  while (i >= 0){
    c->cifre[k] = (a->cifre[i] + prenos) % 10;
    prenos	   = (a->cifre[i] + prenos) / 10;
    
    i--;
    k--;
  }
  //slucaj da je drugi broj veci
  while (j >= 0){
    c->cifre[k] = (b->cifre[j] + prenos) % 10;
    prenos  	 = (b->cifre[j] + prenos) / 10;
    
    j--;
    k--;
  }
  //ako imamo prenos na kraju, povecavamo broj cifara u rezultatu za 1
  if (prenos > 0){
    //pomeramo cifre broja udesno da bismo prenos dodali na pocetak
    for(i=c->broj_cifara; i>0; i--)
      c->cifre[i] = c->cifre[i-1];
    
    c->cifre[0] = prenos;
    
    c->broj_cifara += 1;
  }
  //vracamo veliki broj c koji je zbir a i b	
  return c;
}

/*Funkcija koja mnozi veliki broj a sa cifrom c
Funckija takodje alocira memoriju za rezultat, pa je treba osloboditi u main-u 
*/
VelikiBroj *mnozi_sa_cifrom(const VelikiBroj *a, int c){
  VelikiBroj *rezultat;

  //alociramo memoriju za rezultat
  rezultat=malloc(sizeof(VelikiBroj));
  if(rezultat==NULL)
    greska();
  
  //podesavamo broj cifara rezultata
  rezultat->broj_cifara = a->broj_cifara; // + 1
  rezultat->cifre = NULL;

  //alociramo memoriju za cifre 
  rezultat->cifre = malloc((rezultat->broj_cifara+1)*sizeof(int));
  if (rezultat->cifre == NULL)
    greska();
		
  int prenos = 0;
  int i;
  //svaki put mnozimo cifru c sa cifrom broja i pamtimo prenos
  for(i=a->broj_cifara-1; i>=0; i--){
      rezultat->cifre[i] = (a->cifre[i]*c + prenos) % 10;
      prenos = (a->cifre[i]*c + prenos) / 10;
  }
  
  //ako je prenos na kraju veci od nule, povecavamo broj cifara rezultata
  if (prenos > 0){
    rezultat->broj_cifara += 1;

    //pomeramo cifre udesno, da bismo dodali prenos na pocetak broja
    for(i=rezultat->broj_cifara-1; i>0; i--)
      rezultat->cifre[i] = rezultat->cifre[i-1];
    
    rezultat->cifre[0] = prenos;
  }
  
  return rezultat;
}

VelikiBroj *pomnozi(const VelikiBroj *a,const  VelikiBroj* b){
  VelikiBroj *rezultat;

  //memorija za rezultat
  rezultat=malloc(sizeof(VelikiBroj));
  if(rezultat==NULL)
    greska();

  //podesavamo broj cifara broja
  rezultat->broj_cifara=0;
  
  //alociramo memoriju za cifre rezultata
  rezultat->cifre=calloc(a->broj_cifara+b->broj_cifara,sizeof(int));
  if(rezultat->cifre==NULL)
    greska();

  //inicijalno u rezultat smestamo broj a
  for(int i=0;i<a->broj_cifara;i++)
    rezultat->cifre[i]=a->cifre[i];

  VelikiBroj *tmp=NULL;//pomocni broj koji sluzi za mnozenje broja a sa cifrom broja b
  VelikiBroj *tmp2=NULL; //pomocni broj koji sluzi da saberemo prethodni rezultat sa tmp
  int i;
  
  //mnozenje radimo tako sto broj a mnozimo sa cifrom broja b, zatim sabiramo sa prethodnim rezultatom i mnozimo sa 10 (horner)
  for(i=0;i<b->broj_cifara;i++){   
    tmp=mnozi_sa_cifrom(a,b->cifre[i]);

    tmp2=saberi(rezultat,tmp);

    //OBAVEZNO oslobadjamo tmp i tmp2, jer im u narednoj iteraciji dodeljujemo novu memoriju, pa dolazi do ozbiljnog curenja memorije 
    //sada oslobadjamo tmp, jer smo s njim zavrsili
    free(tmp->cifre);
    free(tmp);
  
    rezultat->broj_cifara=tmp2->broj_cifara;
    //upisujemo tmp2 u rezultat, jer je tmp2 zapravo novi rezultat
    for(int j=0;j<tmp2->broj_cifara;j++)
      rezultat->cifre[j]=tmp2->cifre[j];

    //sada mozemo i tmp2 da oslobodimo, bitno je da bude pre kraja trenutne iteracije petlje
    free(tmp2->cifre);
    free(tmp2);
  
    //ovo je zapravo mnozenje sa 10, tj dodajemo 0 sa desne strane, ali kada stignemo do poslednje cifre broja b, onda ne mnozimo
    if(i!=b->broj_cifara-1)
      rezultat->broj_cifara++;   
  }

  return rezultat;
}

VelikiBroj *faktorijel(int n){
  VelikiBroj *rezultat;

  //smestamo n u fajl, da bismo ga lakse ucitali jer vec imamo funkciju
  // 'ucitaj' koja ucitava broj iz fajla
  FILE *tmp=fopen("tmp.txt","w");
  if(tmp==NULL)
    greska();

  fprintf(tmp,"%d",n);
  fclose(tmp);

  //otvaramo ga opet da bismo citali od pocetka fajla. Ovo se moze zaobici
  //koriscenjem funkcije fseek (pogledati koga zanima)
  tmp=fopen("tmp.txt","r");
  rezultat=ucitaj(tmp);

  int i=n-1;
  while(i>=2){
    //isto radimo za svako i od 2 do n-1, smestamo u fajl pa ucitavamo iz fajla
    FILE *tmp=fopen("tmp.txt","w");
    if(tmp==NULL)
      greska();
    
    fprintf(tmp,"%d",i);
    fclose(tmp);

    tmp=fopen("tmp.txt","r");
    VelikiBroj* vb_i=ucitaj(tmp);
    
    //proizvod=i*rezultat;
    VelikiBroj *proizvod=pomnozi(rezultat,vb_i);

    //oslobadjamo vb_i da ne bi doslo do curenja memorije
    free(vb_i->cifre);
    free(vb_i);

    //oslobadjamo rezultat i alociramo ponovo da smestimo proizvod tu
    free(rezultat->cifre);
    free(rezultat);
    
    rezultat=malloc(sizeof(VelikiBroj));
    rezultat->broj_cifara=proizvod->broj_cifara;
    rezultat->cifre=malloc(sizeof(int)*proizvod->broj_cifara);

    //kopiramo cifre iz proizvoda u rezultat
    for(int j=0;j<proizvod->broj_cifara;j++){
      rezultat->cifre[j]=proizvod->cifre[j];
    }
    
    i--;
  }

  return rezultat;
}
