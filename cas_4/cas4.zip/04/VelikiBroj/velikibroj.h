#ifndef _VB_H_ 
#define _VB_H_ 1

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define KORAK 10

/*Struktura opisuje veliki broj njegovim ciframa i brojem cifara.
Ova struktura sadrzi samo pokazivac na niz cifara, NE SADRZI same cifre. 
Stoga, koliko god cifara imao broj, ova struktura zauzima 
samo onoliko memorije koliko je potrebno za smestanje pokazivaca na int, i jedan int 
(uglavnom je to (8 za pokazivac + 4 za int) bajtova)
*/
typedef struct
{
	int* cifre;
	int  broj_cifara;
}VelikiBroj;

void greska();
VelikiBroj *ucitaj(FILE *f);
void ispis(const VelikiBroj *vb, FILE *g);
int poredi(const VelikiBroj *vb1,const VelikiBroj *vb2);
VelikiBroj *saberi(const VelikiBroj *a,const  VelikiBroj *b);
VelikiBroj *mnozi_sa_cifrom(const VelikiBroj *a, int c);
VelikiBroj *pomnozi(const VelikiBroj *a,const VelikiBroj *b);
VelikiBroj *faktorijel(int n);
#endif

