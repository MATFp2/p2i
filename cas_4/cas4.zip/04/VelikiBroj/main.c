#include "velikibroj.h"

/*U ovom resenju postoji izmena u odnosu na pdf koji je okacen na sajtu.
Ovde radimo sa pokazivacima na strukture, ali moguce je prenositi celu
strukturu kao arugment funkcije. Vise o strukturi VelikiBroj u .h fajlu
*/
//DODATNO izracunati 100!


int main(int argc, char** argv){
  int i;

  
  if (argc != 2)
    greska();
		
  FILE* f = fopen(argv[1], "r");
  if (f == NULL)
    greska();
		
  FILE *g = fopen("velikibrojizlaz.txt", "w");
  if (g == NULL)
    greska();

  //Napomena: memorija za vb1 i vb2 se alocira unutar funkcije ucitaj
  //pa mi moramo da oslobodimo memoriju u main-u kasnije
  VelikiBroj *vb1 = ucitaj(f);
  VelikiBroj *vb2 = ucitaj(f);
  fclose(f);  //zatvaramo f jer smo zavrsili s ucitavanjem 

  fprintf(g,"Broj a: ");
  ispis(vb1, g);
  
  fprintf(g,"Broj b: ");
  ispis(vb2, g);
  fprintf(g,"Poredjenje: %d\n", poredi(vb1, vb2));
	
  VelikiBroj *vb3 = saberi(vb1, vb2);
  fprintf(g,"a+b: ");
  ispis(vb3, g);
  
  fprintf(g,"a*9: ");
  VelikiBroj *vb4 = mnozi_sa_cifrom(vb1, 9);  
  ispis(vb4,g);

  fprintf(g,"a*b: ");
  VelikiBroj *vb5 = pomnozi(vb1,vb2);
  ispis(vb5,g);
  
  VelikiBroj *vb6=faktorijel(100);
  fprintf(g,"faktorijel: ");
  ispis(vb6,g);

  fclose(g);

  //kada oslobadjamo memoriju, setimo se da smo alocirali i memoriju
  //za strukturu i memoriju za clan strukture (cifre), pa moramo
  //da oslobodimo prvo to unutra, pa spolja
  
  free(vb1->cifre);
  free(vb2->cifre);
  free(vb3->cifre);
  free(vb4->cifre);
  free(vb5->cifre);
  free(vb6->cifre);
  
  free(vb1);
  free(vb2);
  free(vb3);
  free(vb4);
  free(vb5);
  free(vb6);
  return 0;
}
